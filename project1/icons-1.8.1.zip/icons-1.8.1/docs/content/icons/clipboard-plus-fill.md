---
title: Clipboard plus fill
categories:
  - Real world
tags:
  - copy
  - paste
---
