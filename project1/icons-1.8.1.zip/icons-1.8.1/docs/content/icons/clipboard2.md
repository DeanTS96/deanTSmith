---
title: Clipboard2
categories:
  - Real world
tags:
  - copy
  - paste
---
